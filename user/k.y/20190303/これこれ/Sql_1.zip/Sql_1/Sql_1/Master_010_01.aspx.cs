﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;



namespace Sql_1
{
    public partial class syain : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void MasterRegistration(Object sender, EventArgs e)
        {

            string connectionString = string.Format("Server=127.0.0.1; database=usr; UID=root; password=pokopoko123; SslMode = none");
            MySqlConnection con = new MySqlConnection(connectionString);
            // コマンドを作成
            // MySqlCommand cmd = new MySqlCommand("insert into user values (@uid, @passwd)", con);
            // コマンドを作成
            MySqlCommand cmd =
                new MySqlCommand("insert into member " +
                "( id, name, initial,adress,station,information,attach,position,status) " +
                "values ( @id, @name, @initial,@adress,@station,@information,@attach,@position,@status )", con);
            // パラメータ設定
            cmd.Parameters.Add(
                new MySqlParameter("id", MstTxtId.Text));
            cmd.Parameters.Add(
                new MySqlParameter("name", MstTxtName.Text));
            cmd.Parameters.Add(
               new MySqlParameter("initial", MstTxtInitial.Text));
            cmd.Parameters.Add(
               new MySqlParameter("adress", MstTxtAdress.Text));
            cmd.Parameters.Add(
               new MySqlParameter("station", MstTxtStation.Text));
            cmd.Parameters.Add(
               new MySqlParameter("information", MstTxtInformation.Text));
            cmd.Parameters.Add(
               new MySqlParameter("attach", MstTxtAttach.Text));
            cmd.Parameters.Add(
               new MySqlParameter("position", MstTxtPosition.Text));
            cmd.Parameters.Add(
               new MySqlParameter("status", MstTxtStatus.Text));
            

            try
            {
                // オープン
                cmd.Connection.Open();
                // 実行
                cmd.ExecuteNonQuery();
                // クローズ
                cmd.Connection.Close();
                Response.Redirect("Login_040.aspx");
            }
            catch (SqlException ex)
            {
                // 例外処理
                System.Diagnostics.Debug.WriteLine(ex);
            }
        }
    }
}