﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;


namespace Sql_1
{
    public partial class Master_010_02 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void MasterRegistration_02(Object sender, EventArgs e)
        {

            string connectionString = string.Format("Server=127.0.0.1; database=usr; UID=root; password=pokopoko123; SslMode = none");
            MySqlConnection con = new MySqlConnection(connectionString);
            // コマンドを作成
            MySqlCommand cmd =
                new MySqlCommand("insert into deal " +
                "( id, numero, dealcol,customer,work,cost,require,term) " +
                "values ( @id, @numero, @dealcol,@customer,@work,@cost,@require,@term )", con);  //,require,term,@require,@term
            // パラメータ設定
            cmd.Parameters.Add(
                new MySqlParameter("id", MstTxtId.Text));
            cmd.Parameters.Add(
                new MySqlParameter("numero", MstTxtNumero.Text));
            cmd.Parameters.Add(
               new MySqlParameter("dealcol", MstTxtDealcol.Text));
            cmd.Parameters.Add(
               new MySqlParameter("customer", MstTxtCustomer.Text));
            cmd.Parameters.Add(
               new MySqlParameter("work", MstTxtWork.Text));
            cmd.Parameters.Add(
               new MySqlParameter("cost", MstTxtCost.Text));
            cmd.Parameters.Add(
                new MySqlParameter("require", MstTxtRequire.Text));
            cmd.Parameters.Add(
                new MySqlParameter("term", MstTxtTerm.Text));

            try
            {
                // オープン
                cmd.Connection.Open();
                // 実行
                cmd.ExecuteNonQuery();
                // クローズ
                cmd.Connection.Close();
                Response.Redirect("Login_040.aspx");
            }
            catch (SqlException ex)
            {
                // 例外処理
                System.Diagnostics.Debug.WriteLine(ex);
            }
        }
    }
}